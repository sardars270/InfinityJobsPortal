public class main {
    public static void main(String[] args) {
        Shape s=new Shape();
        System.out.println("A Shape with color of " + s.getColor() + " and is  " +s.isFilled());
     Circle c =new Circle();
        System.out.println("The circle has radius of "
                + c.getRadius() + " and area of " + c.getArea()+ " and perimeter of "+c.getPerimeter()) ;
        Rectangle r =new Rectangle();
        System.out.println("The Rectangle has length of "+r.getLength()+"and width of  "+r.getWidth()+" and area of " + r.getArea()+ " and perimeter of "+r.getPerimeter());
      Square sq =new Square();
        System.out.println("The Square has side of "+sq.getSide()+" and area of " + sq.getArea()+ " and perimeter of "+sq.getPerimeter());
    }
}
