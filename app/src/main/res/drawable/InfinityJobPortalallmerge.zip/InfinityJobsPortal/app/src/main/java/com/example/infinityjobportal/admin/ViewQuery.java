package com.example.infinityjobportal.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.infinityjobportal.R;

public class ViewQuery extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_activity_view_query);
    }
}