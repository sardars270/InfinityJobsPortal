package com.example.infinityjobportal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SavedJobsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_jobs);
    }
}