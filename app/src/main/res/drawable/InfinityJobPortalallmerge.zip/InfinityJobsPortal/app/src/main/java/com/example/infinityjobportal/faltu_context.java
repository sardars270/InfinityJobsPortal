package com.example.infinityjobportal;

import android.content.Context;

public class faltu_context {
    public static Context context;
}
